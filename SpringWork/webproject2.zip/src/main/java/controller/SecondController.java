package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SecondController {
	@RequestMapping("/first")
	public String firstPage() {
		return "/WEB-INF/views/first.jsp";
	}
}
